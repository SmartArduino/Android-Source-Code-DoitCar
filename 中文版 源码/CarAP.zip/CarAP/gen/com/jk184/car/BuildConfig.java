/** Automatically generated file. DO NOT MODIFY */
package com.jk184.car;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}